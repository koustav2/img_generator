require('dotenv').config(".env");
const express = require('express');
const app = express();
const cors = require('cors');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const PORT = process.env.PORT || 5000;
const { OpenAI } = require('openai');
const openai = new OpenAI({
  apiKey: "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",
  organization:'org-EYmQFPE9Nt1jt6Dy4mmMvHue'
});

// Middleware to parse JSON bodies
app.use(cors({
  origin: '*'
}))
app.use(express.json());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));

app.use(cookieParser());

// app.use("/api/v1", require("./openAi/img_generator"))
module.exports.app.get('/api/v1', function async (req, res) {
  res.status(200).json({
      message: 'Hey this is my API running 🥳'
  })
})
module.exports.app.post('/api/v1/generate-image', async (req, res) => {
  const { prompt, size } = req.body;

  const imageSize =
      size === 'small' ? '256x256' : size === 'medium' ? '512x512' : '1024x1024';
  try {
      const options = ["vivid", "natural"]
      const randomIndex = Math.floor(Math.random() * options.length);
      const response = await openai.images.generate({
          prompt: prompt,
          model: "dall-e-3",
          response_format: 'url',
          size: imageSize ? imageSize : "1024x1024",
          style: options[randomIndex],
          quality: "hd"

      })
      const imageUrl = response.data.map(elm => elm.url)

      res.status(200).json({
          success: true,
          data: imageUrl[0],
      });
  } catch (error) {
      res.status(400).json({
          success: false,
          error: 'The image could not be generated',
      });
  }
})
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
